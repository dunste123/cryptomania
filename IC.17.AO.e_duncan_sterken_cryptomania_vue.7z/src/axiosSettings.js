import axios from 'axios'

axios.defaults.baseURL = 'https://api.coincap.io/v2';
