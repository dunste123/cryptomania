module.exports = {
    outputDir: 'docs',
    productionSourceMap: false,
};
